pdflatex gd1_mepp.tex
bibtex gd1_mepp.aux
pdflatex gd1_mepp.tex
pdflatex gd1_mepp.tex
